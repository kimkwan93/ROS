#include "ros/ros.h"                                   
#include "mytoss/mymsg.h"
#include <cstdlib>           


void msgCallback(const mytoss::mymsg::ConstPtr& msg)

{
  ros::Rate loop_rate(1);
  ros::NodeHandle nh;
  ROS_INFO("recieved msg: %d", msg->data);
  loop_rate.sleep();
  mytoss::mymsg msgx;
  ros::Publisher mypub2 = nh.advertise<mytoss::mymsg>("Topic2", 100);
    
  switch(msg->data)
	{
	case 0:
	    msgx.data=1;
	    mypub2.publish(msgx);
            ROS_INFO("sent msg: 1");
	    break;
	case 1:
	    msgx.data=2;
	    mypub2.publish(msgx);
 	    ROS_INFO("sent msg: 2");
	    break;
	case 2:
	    msgx.data=3;
	    mypub2.publish(msgx);
 	    ROS_INFO("sent msg: 3");
	    break;
	case 3:
	    msgx.data=1;
	    mypub2.publish(msgx);
 	    ROS_INFO("sent msg: 1");
	    break;
	}
  loop_rate.sleep();

}


int main(int argc, char **argv)                        
{

  ros::init(argc, argv, "mysubscriber"); 
  ros::NodeHandle nh;                                 
  ros::Publisher mypub2 = nh.advertise<mytoss::mymsg>("Topic2", 100);
  ros::Subscriber mysub2 = nh.subscribe("Topic1", 100, msgCallback);
  ros::spin();

  return 0;
}
