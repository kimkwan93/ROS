#include "ros/ros.h"  
#include "mytoss/mymsg.h"        
#include <cstdlib>


void msgCallback(const mytoss::mymsg::ConstPtr& msg)

{
  ros::Rate loop_rate(1);
  ros::NodeHandle nh;
  ROS_INFO("recieved msg: %d", msg->data);
  loop_rate.sleep();
  mytoss::mymsg msgx;    
  ros::Publisher mypub1 = nh.advertise<mytoss::mymsg>("Topic1", 100);

  switch(msg->data)
	{
	case 0:
	    msgx.data=1;
	    mypub1.publish(msgx);
            ROS_INFO("sent msg: 1");
	    break;
	case 1:
	    msgx.data=2;
	    mypub1.publish(msgx);
 	    ROS_INFO("sent msg: 2");
	    break;
	case 2:
	    msgx.data=3;
	    mypub1.publish(msgx);
 	    ROS_INFO("sent msg: 3");
	    break;
	case 3:
	    msgx.data=1;
	    mypub1.publish(msgx);
 	    ROS_INFO("sent msg: 1");
	    break;
	}
  loop_rate.sleep();


}





int main(int argc, char **argv)                        

{

  ros::init(argc, argv, "mypublisher");  
  ros::NodeHandle nh;                                  
  ros::Rate loop_rate(1);

  ros::Publisher mypub1 = nh.advertise<mytoss::mymsg>("Topic1", 100);
  ros::Subscriber mysub1 = nh.subscribe("Topic2", 100, msgCallback);

  int count = 0;
  loop_rate.sleep();
  mytoss::mymsg msg;    
  msg.data = count;
  ROS_INFO("sent msg = %d", msg.data);
  mypub1.publish(msg);


  ros::spin();

  return 0;

}
