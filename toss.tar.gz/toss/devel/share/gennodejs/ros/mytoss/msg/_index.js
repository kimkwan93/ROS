
"use strict";

let mymsg = require('./mymsg.js');

module.exports = {
  mymsg: mymsg,
};
